A very basic demo. Connect/Close and read a comming message in a single Text UI element.
This demo isn't optemized at all, it's just to understand how the API works.

Note : BasicDemo.cs script is already attached to the 'MyScript' gameobject in the scene.

Warning : you need to alter the 'Name' or 'MacAdress' in the Awake() method in the script 'BasicDemo.cs' to match your module.