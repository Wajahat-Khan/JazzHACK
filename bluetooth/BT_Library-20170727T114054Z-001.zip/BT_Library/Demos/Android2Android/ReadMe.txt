﻿It's the same as the regular "Bluetooth Terminal" demo but with Android to Android connection.
 One Android will work as a server and the other as a client. (This is One to One connection not one to many, but you can to tweak it).
 Notice that you need to work with a new property called UUID, check out the ServerClient.cs script.

Note : 'ServerClient.cs' script is already attached to the 'InfoController' gameobject in the scene.
