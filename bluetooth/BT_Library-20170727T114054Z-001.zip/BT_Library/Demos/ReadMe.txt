To learn from the demos use them in the following order :

1) Basic demo.
2) Automatic Connection.
3) Bluetooth Terminal.

Then choose whatever you want!

Note : The 'BtConnector' gameobject is added to every scene, so no need to do this step. 