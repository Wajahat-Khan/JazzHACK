This demo will try to connect to your module at load time automatically.
You should alter either the Name or the MacAdress property to match your module in the AutoConnect.cs script.

Note : AutoConnect.cs script is already attached to the 'MyScript' gameobject in the scene.

Warning : you need to alter the 'Name' or 'MacAdress' in the Awake() method in the script 'BasicDemo.cs' to match your module.