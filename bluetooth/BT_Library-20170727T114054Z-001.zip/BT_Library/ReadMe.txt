Please don't forget to setup the BT library :

From the menu bar, go to [ Tools -> TechTweaking -> Bluetooth Classic -> Setup the BT library ]